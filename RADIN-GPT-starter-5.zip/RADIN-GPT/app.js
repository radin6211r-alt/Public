const form = document.getElementById('chat-form');
const input = document.getElementById('prompt');
const chat = document.getElementById('chat');

form.addEventListener('submit', (event) => {
  event.preventDefault();
  const value = input.value.trim();
  if (!value) return;

  const message = document.createElement('div');
  message.className = 'message user';
  message.textContent = value;
  chat.appendChild(message);
  input.value = '';

  const reply = document.createElement('div');
  reply.className = 'message assistant';
  reply.textContent = 'پیامت در رابط آزمایشی ثبت شد. هنوز موتور هوش مصنوعی به این نسخه متصل نشده است.';
  chat.appendChild(reply);
  chat.scrollTop = chat.scrollHeight;
});
