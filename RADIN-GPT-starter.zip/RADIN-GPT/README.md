# RADIN GPT

A Persian-first, responsive AI workspace starter for the RADIN GPT project.

## Included
- RTL Persian interface
- Responsive desktop and mobile layout
- Basic chat UI and local conversation list
- Starter cards for common tasks
- Clear placeholders for image, video, and voice integrations

## Important status
This repository currently contains the **frontend starter only**. It is not yet connected to an AI model. The image, video, and voice controls are placeholders and do not generate media yet.

To enable real AI chat and media generation, add a backend that calls provider APIs securely. Keep API keys on the server in environment variables; never place secret keys in browser JavaScript.

## Run locally
Open `index.html` in a browser, or serve this folder with any static web server.

## Deploy
The project can be deployed as a static website (for example, GitHub Pages or another static host).

## Developer
Radin Dehzagi
