const form = document.getElementById('chatForm');
const input = document.getElementById('prompt');
const messages = document.getElementById('messages');
const welcome = document.getElementById('welcome');
const history = document.getElementById('history');
let titles = [];

function addMessage(text, role) {
  welcome.style.display = 'none';
  const el = document.createElement('div');
  el.className = `message ${role}`;
  el.textContent = text;
  messages.appendChild(el);
  messages.scrollIntoView({behavior:'smooth', block:'end'});
}
function send(text) {
  const value = (text || '').trim();
  if (!value) return;
  addMessage(value, 'user');
  if (!titles.includes(value)) {
    titles.unshift(value);
    history.innerHTML = '';
    titles.slice(0,8).forEach(t => {
      const item = document.createElement('div');
      item.className = 'history-item';
      item.textContent = t;
      history.appendChild(item);
    });
  }
  addMessage('این نسخه فعلاً رابط کاربری اولیه RADIN GPT است و هنوز به مدل هوش مصنوعی متصل نشده. برای فعال شدن پاسخ‌های واقعی باید در مرحله بعد یک سرور امن و API مدل به پروژه اضافه کنیم.', 'assistant');
  input.value = '';
  input.style.height = 'auto';
}
form.addEventListener('submit', e => { e.preventDefault(); send(input.value); });
input.addEventListener('input', () => { input.style.height='auto'; input.style.height=Math.min(input.scrollHeight,140)+'px'; });
document.querySelectorAll('[data-prompt]').forEach(btn => btn.addEventListener('click', () => send(btn.dataset.prompt)));
document.getElementById('newChat').addEventListener('click', () => {
  messages.innerHTML = '';
  welcome.style.display = 'block';
  input.value = '';
  document.querySelector('.sidebar').classList.remove('open');
});
document.getElementById('menuBtn').addEventListener('click', () => document.querySelector('.sidebar').classList.toggle('open'));
